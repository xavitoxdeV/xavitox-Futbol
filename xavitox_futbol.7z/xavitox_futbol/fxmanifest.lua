fx_version 'cerulean'
games {'gta5' }


client_scripts {
    'cliente.lua'
}

server_scripts {
    'server.lua'
}


